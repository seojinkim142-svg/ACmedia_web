export default function FeedPage() {
  return <h1 className="text-2xl font-bold">피드 페이지</h1>;
}
